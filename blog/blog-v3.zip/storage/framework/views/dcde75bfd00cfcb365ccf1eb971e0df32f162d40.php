<?php $__env->startSection('content'); ?>

	<?php if(count($errors) > 0): ?>
		<ul class="list-group">
			<?php $__currentLoopData = @errors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
				<li class="list-group-item text-danger">
					<?php echo e($error); ?>

				</li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
		</ul>
	<?php endif; ?>

	<div class="panel panel-default">
		<div class="panel-heading">
			Edit Blog Settings
		</div>
		<div class="panel-body">
			<form action="<?php echo e(route('settings.update')); ?>" method="post" enctype="multipart/form-data">
				<?php echo e(csrf_field()); ?>

				
				<div class="form-group">
					<label for="site_name">Site Name</label>
					<input type="text" name="site_name" value="<?php echo e($settings->site_name); ?>" class="form-control"> 
				</div>
				<div class="form-group">
					<label for="address">Address</label>
					<input type="text" name="address" value="<?php echo e($settings->address); ?>" class="form-control">
				</div>
				<div class="form-group">
					<label for="contact_number">Site Contact NUmber</label>
					<input type="text" name="contact_number" value="<?php echo e($settings->contact_number); ?>" class="form-control">
				</div>
				<div class="form-group">
					<label for="contact_email">Site Email</label>
					<input type="text" name="contact_email" value="<?php echo e($settings->contact_email); ?>" class="form-control">
				</div>
				<div class="form-group">
					<div class="text-center">
						<button class="btn btn-success">Update Settings</button>
					</div>
				</div> 
			</form>
		</div>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>