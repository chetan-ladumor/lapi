<?php $__env->startSection('content'); ?>

	<div class="panel panel-default">
		<div class="panel-body">
			<table class="table table-hover">
				<thead>
					<th>
						Image
					</th>
					<th>
						Title
					</th>
					<th>
						Content
					</th>
					<th>
						Category
					</th>
					<th>
						Edit
					</th>
					<th>
						Delete
					</th>
				</thead>
				<tbody>
					<?php if($posts->count() > 0): ?>
						<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
							<tr>
								<td>
									<img src="<?php echo e($post->featured); ?>" width="90px" height="90px">
								</td>
								<td>
									<?php echo e($post->title); ?>

								</td>
								<td>
									<?php echo e($post->content); ?>

								</td>
								<td>
									<?php echo e($post->category_id); ?>

								</td>
								<td>
									<a href="<?php echo e(route('posts.kill',[ 'id' => $post->id ])); ?>" class="btn btn-xs btn-danger">
									Delete	
									</a>
								</td>
								<td>
									<a href="<?php echo e(route('posts.restore',[ 'id' => $post->id ])); ?>" class="btn btn-xs btn-success">
									Restore
									</a>
								</td>
							</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
					<?php else: ?>
						<tr>
							<th colspan="5" class="text-center">NO trashed posts.</th>
						</tr>
					<?php endif; ?>
				</tbody>
			</table>
		</div>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>