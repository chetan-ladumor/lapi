<?php $__env->startSection('content'); ?>

	<?php if(count($errors) > 0): ?>
		<ul class="list-group">
			<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
				<li class="list-group-item text-danger">
					<?php echo e($error); ?>

				</li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
		</ul>
	<?php endif; ?>
   <div class="panel panel-default">
   		<div class="panel-heading">
   			Create a new tag
   		</div>
   		<div class="panel-body">
   			<form action="<?php echo e(route('tag.store')); ?>" method="post" >

   				<?php echo e(csrf_field()); ?>


   				<div class="form-group">
   					<label for="tag">Name</label>
   					<input type="text" name="tag" class="form-control">
   				</div>

               <div class="form-group">
                  <button class="btn btn-success" type="submit">Save Tag</button>
               </div>
   				
   			</form>
   		</div>
   </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>